<?php

namespace CommerceGuys\Tax\Exception;

interface ExceptionInterface
{
}
