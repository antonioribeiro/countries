# Versions

## v0.0.6 - (2016/08/16)

* Updated Russian and Belorussian roubles.


## v0.0.5 - (2014/08/20)

* Added missing major symbol for Indian Ruppies (INR).


## v0.0.4 - (2014/08/12)

* Bumped version to fix republish on NPM.


## v0.0.3 - (2014/08/12)

* Renamed project from `currency` to `world-currencies`.
* Added index.js and published NPM package.
* Renamed and republished bower package.


## v0.0.2 - (2014/08/05)

* Added all the ISO 4217 listed currencies.


## v0.0.1 - (2014/07/25)

* Initial commit of the project.
